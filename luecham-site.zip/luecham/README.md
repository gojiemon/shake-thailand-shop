# ลือชาม ก๋วยเตี๋ยวเรือ — Restaurant Website

A production-ready, mobile-first one-page restaurant website in Thai language.
Built with **Next.js 14 (App Router) + TypeScript + Tailwind CSS**.

## 🚀 Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Run development server
npm run dev

# 3. Open in browser
open http://localhost:3000
```

## ⚙️ Configuration

Before going live, update these constants in **`app/constants.ts`** AND in **`app/page.tsx`**:

| Constant | Default | What to change |
|---|---|---|
| `MAP_URL` | Generic Google Maps search | Paste your Google Maps share link |
| `DELIVERY_URL` | Foodpanda homepage | Paste your store's Foodpanda/GrabFood/LINE MAN URL |

## 🖼️ Adding Real Images

Place images in `public/images/`:

```
public/
  images/
    gallery-1.jpg   — ก๋วยเตี๋ยวเรือหมู
    gallery-2.jpg   — หมี่กระเฉดกุ้ง
    gallery-3.jpg   — สุกี้แห้งทะเล
    gallery-4.jpg   — บรรยากาศร้าน
    gallery-5.jpg   — มุมสวน
    gallery-6.jpg   — เมนูอื่นๆ
```

Recommended size: **800×800px** minimum, JPEG/WebP format.

## 📁 Project Structure

```
luecham/
├── app/
│   ├── constants.ts      ← URLs & restaurant info
│   ├── globals.css       ← Tailwind + custom styles
│   ├── layout.tsx        ← HTML shell, metadata, fonts
│   └── page.tsx          ← Main page assembler
├── components/
│   ├── TopBar.tsx        ← Sticky nav with CTA buttons
│   ├── Hero.tsx          ← Hero section
│   ├── Highlights.tsx    ← 5 feature cards
│   ├── Menu.tsx          ← 8-item menu grid
│   ├── Gallery.tsx       ← 6-image gallery (with fallback)
│   ├── Reviews.tsx       ← 3 customer quotes
│   ├── Info.tsx          ← Hours, phone, address
│   ├── Location.tsx      ← Map placeholder + directions
│   └── Footer.tsx        ← Links, social placeholders
└── public/
    └── images/           ← Put your photos here
```

## 🔧 Production Build

```bash
npm run build
npm start
```

## 📱 Features

- ✅ Mobile-first responsive design
- ✅ Sticky top bar with Phone / Map / Delivery CTAs
- ✅ Thai language throughout
- ✅ SEO: title, meta description, OpenGraph tags
- ✅ Semantic HTML + accessible buttons + alt text
- ✅ Google Font: Sarabun (Thai-optimized)
- ✅ Works without images (graceful fallback)
- ✅ Fast: no external UI kits
