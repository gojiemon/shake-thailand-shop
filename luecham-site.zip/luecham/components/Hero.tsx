import { MAP_URL, DELIVERY_URL, PHONE } from '../app/constants'

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative overflow-hidden bg-gradient-to-br from-brand-600 via-brand-700 to-clay pt-12 pb-16 sm:pt-16 sm:pb-24"
      aria-labelledby="hero-heading"
    >
      {/* Decorative circles */}
      <div className="pointer-events-none absolute -top-20 -right-20 h-64 w-64 rounded-full bg-brand-400/20" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-10 -left-10 h-48 w-48 rounded-full bg-brand-800/30" aria-hidden="true" />

      {/* Bowl decoration */}
      <div className="pointer-events-none absolute top-4 right-6 text-6xl opacity-10 select-none" aria-hidden="true">🍜</div>

      <div className="relative mx-auto max-w-2xl px-5 text-center text-white">
        {/* Badge */}
        <div className="fade-up mb-4 inline-block rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium backdrop-blur-sm">
          ไม่ต้องดัง แต่คนพื้นที่รู้ดี
        </div>

        {/* Heading */}
        <h1
          id="hero-heading"
          className="fade-up fade-up-delay-1 text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl"
        >
          ลือชาม
          <br />
          <span className="text-brand-200">ก๋วยเตี๋ยวเรือ</span>
        </h1>

        <p className="fade-up fade-up-delay-2 mt-5 text-lg text-white/85 leading-relaxed">
          ก๋วยเตี๋ยวเรือรสเข้มข้น พร้อมเมนูตามสั่งหลากหลาย
          <br className="hidden sm:block" />
          จะกินเส้นหรือกินข้าวก็มาจบได้ที่นี่
        </p>

        {/* Sub taglines */}
        <div className="fade-up fade-up-delay-2 mt-4 flex flex-wrap justify-center gap-2 text-sm text-white/70">
          {['เข้มข้นทุกชาม อิ่มคุ้มทุกวัน', 'เช้าไหนก็แวะได้', 'มากับเพื่อนก็สั่งได้คนละอย่าง'].map((t) => (
            <span key={t} className="rounded-full bg-white/10 px-3 py-1">{t}</span>
          ))}
        </div>

        {/* CTAs */}
        <div className="fade-up fade-up-delay-3 mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <a
            href={`tel:${PHONE}`}
            className="w-full sm:w-auto btn-primary bg-white text-brand-700 hover:bg-brand-50 text-lg px-8 py-4 shadow-lg"
            aria-label="โทรสั่งอาหาร"
          >
            📞 โทรสั่งเลย
          </a>
          <a
            href={DELIVERY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto btn-outline border-white/60 text-white hover:bg-white/10 text-lg px-8 py-4"
            aria-label="สั่งเดลิเวอรี่ออนไลน์"
          >
            🛵 สั่งเดลิเวอรี่
          </a>
          <a
            href={MAP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto btn-outline border-white/60 text-white hover:bg-white/10 text-lg px-8 py-4"
            aria-label="ดูแผนที่ร้าน"
          >
            📍 ดูแผนที่
          </a>
        </div>
      </div>
    </section>
  )
}
