import { PHONE, PHONE_DISPLAY, HOURS, ADDRESS } from '../app/constants'

export default function Info() {
  return (
    <section id="info" className="bg-warm py-14 px-4" aria-labelledby="info-heading">
      <div className="mx-auto max-w-3xl">
        <h2 id="info-heading" className="section-title text-center mb-10">เวลาเปิด-ปิด &amp; ติดต่อ</h2>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {/* Hours */}
          <div className="card p-6 text-center">
            <div className="mb-3 text-3xl" aria-hidden="true">🕐</div>
            <h3 className="text-sm font-semibold text-clay/60 mb-1 uppercase tracking-wide">เวลาเปิดให้บริการ</h3>
            <p className="text-xl font-bold text-brand-600">{HOURS}</p>
            <p className="mt-1 text-sm text-clay/60">ทุกวัน</p>
          </div>

          {/* Phone */}
          <div className="card p-6 text-center">
            <div className="mb-3 text-3xl" aria-hidden="true">📞</div>
            <h3 className="text-sm font-semibold text-clay/60 mb-1 uppercase tracking-wide">เบอร์โทรศัพท์</h3>
            <a
              href={`tel:${PHONE}`}
              className="text-xl font-bold text-brand-600 hover:text-brand-700 underline underline-offset-2"
              aria-label={`โทรหาร้าน ${PHONE_DISPLAY}`}
            >
              {PHONE_DISPLAY}
            </a>
            <p className="mt-1 text-sm text-clay/60">กดโทรได้เลย</p>
          </div>

          {/* Address */}
          <div className="card p-6 text-center">
            <div className="mb-3 text-3xl" aria-hidden="true">📍</div>
            <h3 className="text-sm font-semibold text-clay/60 mb-1 uppercase tracking-wide">ที่อยู่</h3>
            <address className="not-italic text-sm font-medium text-clay leading-relaxed">{ADDRESS}</address>
          </div>
        </div>

        {/* Opening tagline */}
        <div className="mt-6 rounded-2xl bg-brand-600 px-6 py-4 text-center text-white">
          <p className="text-lg font-bold">🌅 เปิดเช้า ทำให้ทุกเช้าเป็นมื้อที่ดี</p>
          <p className="text-sm text-white/75 mt-1">มาก่อน 9 โมงยังมีที่นั่งแน่นอน</p>
        </div>
      </div>
    </section>
  )
}
