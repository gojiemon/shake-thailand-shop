const highlights = [
  { icon: '🍲', title: 'น้ำซุปเข้มข้น', desc: 'ไม่ต้องปรุงเพิ่ม รสชาติลงตัวทุกชาม' },
  { icon: '🍽️', title: 'เมนูหลากหลาย', desc: 'ข้าว / เส้น / ผัด / สปาเก็ตตี้ เลือกได้ตามใจ' },
  { icon: '🌅', title: 'เปิดเช้า 07:30', desc: 'แวะได้ทุกวัน ก่อนไปทำงานหรือพักผ่อน' },
  { icon: '💰', title: 'อิ่มคุ้ม ราคาเป็นมิตร', desc: 'จ่ายไม่แพง ได้คุณภาพที่คุ้มค่าทุกมื้อ' },
  { icon: '👫', title: 'มากับเพื่อนก็ได้', desc: 'สั่งได้คนละอย่าง ไม่ต้องกินเหมือนกัน' },
]

export default function Highlights() {
  return (
    <section id="highlights" className="bg-warm py-14 px-4" aria-labelledby="highlights-heading">
      <div className="mx-auto max-w-5xl">
        <h2 id="highlights-heading" className="section-title text-center mb-2">จุดเด่นของร้าน</h2>
        <p className="text-center text-clay/60 mb-10 text-base">ทำไมคนแถวนี้ถึงแวะประจำ</p>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {highlights.map((h) => (
            <div key={h.title} className="card p-5 text-center hover:shadow-md transition-shadow duration-200">
              <div className="mb-3 text-4xl" aria-hidden="true">{h.icon}</div>
              <h3 className="text-base font-bold text-clay mb-1">{h.title}</h3>
              <p className="text-sm text-clay/65 leading-relaxed">{h.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
