const menuItems = [
  { emoji: '🍜', name: 'ก๋วยเตี๋ยวเรือหมู', tag: 'ยอดนิยม', desc: 'น้ำซุปเข้มข้นสไตล์โบราณ เส้นเหนียวนุ่ม' },
  { emoji: '🥩', name: 'ก๋วยเตี๋ยวเรือเนื้อ', tag: '', desc: 'เนื้อนุ่มลาย ซุปเข้มข้นแบบดั้งเดิม' },
  { emoji: '🦐', name: 'หมี่กระเฉดกุ้ง', tag: 'แนะนำ', desc: 'กุ้งสด กระเฉดกรอบ น้ำยำรสจัด' },
  { emoji: '🦑', name: 'สุกี้แห้งทะเล', tag: 'แนะนำ', desc: 'ทะเลรวม ซอสสุกี้รสเด็ด' },
  { emoji: '🍛', name: 'ข้าวกะเพรา', tag: '', desc: 'กะเพราหอม ไข่ดาว ข้าวหอม' },
  { emoji: '🍝', name: 'ผัดไทยกุ้งสด', tag: '', desc: 'กุ้งสดตัวใหญ่ เส้นผัดไทยกลมกล่อม' },
  { emoji: '🍝', name: 'สปาเก็ตตี้ผัดพริกแห้ง', tag: 'ลองดู', desc: 'ฟิวชันสไตล์ไทย เผ็ดหอม กินง่าย' },
  { emoji: '📋', name: 'เมนูตามสั่งประจำวัน', tag: '', desc: 'ถามพนักงาน เมนูหมุนเวียนตามวัตถุดิบสด' },
]

export default function Menu() {
  return (
    <section id="menu" className="bg-cream py-14 px-4" aria-labelledby="menu-heading">
      <div className="mx-auto max-w-5xl">
        <h2 id="menu-heading" className="section-title text-center mb-2">เมนูแนะนำ</h2>
        <p className="text-center text-clay/60 mb-10 text-base">สั่งอะไรก็อร่อย แต่ตัวนี้ต้องลอง</p>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {menuItems.map((item) => (
            <div
              key={item.name}
              className="card flex items-start gap-3 p-4 hover:shadow-md transition-shadow duration-200"
            >
              <span className="text-3xl flex-shrink-0 mt-0.5" aria-hidden="true">{item.emoji}</span>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h3 className="text-sm font-bold text-clay leading-tight">{item.name}</h3>
                  {item.tag && (
                    <span className="rounded-full bg-brand-100 px-2 py-0.5 text-xs font-semibold text-brand-600 flex-shrink-0">
                      {item.tag}
                    </span>
                  )}
                </div>
                <p className="text-xs text-clay/60 leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-6 text-center text-sm text-clay/50">
          * เมนูอาจมีการเปลี่ยนแปลงตามวัตถุดิบ กรุณาสอบถามพนักงาน
        </p>
      </div>
    </section>
  )
}
