import { PHONE_DISPLAY, HOURS, DELIVERY_URL, MAP_URL } from '../app/constants'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="bg-clay text-white py-10 px-4" role="contentinfo">
      <div className="mx-auto max-w-5xl">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3 mb-8">
          {/* Brand */}
          <div>
            <h2 className="text-lg font-extrabold text-brand-300 mb-1">ลือชาม</h2>
            <p className="text-sm text-white/60 leading-relaxed">
              ก๋วยเตี๋ยวเรือ ถนนข้าวหลามบางแสน
              <br />เข้มข้นทุกชาม อิ่มคุ้มทุกวัน
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-sm font-semibold text-white/80 uppercase tracking-wider mb-3">ลิงก์ด่วน</h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li><a href="#menu" className="hover:text-brand-300 transition-colors">เมนูแนะนำ</a></li>
              <li><a href="#info" className="hover:text-brand-300 transition-colors">เวลาเปิด-ปิด</a></li>
              <li><a href={MAP_URL} target="_blank" rel="noopener noreferrer" className="hover:text-brand-300 transition-colors">แผนที่</a></li>
              <li><a href={DELIVERY_URL} target="_blank" rel="noopener noreferrer" className="hover:text-brand-300 transition-colors">สั่งเดลิเวอรี่</a></li>
            </ul>
          </div>

          {/* Social / Contact */}
          <div>
            <h3 className="text-sm font-semibold text-white/80 uppercase tracking-wider mb-3">ช่องทางอื่นๆ</h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li>📞 {PHONE_DISPLAY}</li>
              <li>🕐 {HOURS} ทุกวัน</li>
              {/* Social placeholders — replace href with real URLs */}
              <li>
                <a href="#" className="hover:text-brand-300 transition-colors" aria-label="Facebook ร้านลือชาม">
                  📘 Facebook (เพิ่ม URL)
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-brand-300 transition-colors" aria-label="Line OA ร้านลือชาม">
                  💚 LINE OA (เพิ่ม URL)
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 text-center text-xs text-white/40">
          <p>© {year} ลือชาม ก๋วยเตี๋ยวเรือ ถนนข้าวหลามบางแสน · สงวนลิขสิทธิ์</p>
        </div>
      </div>
    </footer>
  )
}
