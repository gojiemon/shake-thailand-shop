'use client'
import { MAP_URL, DELIVERY_URL, PHONE } from '../app/constants'

export default function TopBar() {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm border-b border-brand-100">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-2.5">
        {/* Logo / Name */}
        <a href="#hero" className="flex flex-col leading-tight">
          <span className="text-base font-bold text-brand-600 leading-none">ลือชาม</span>
          <span className="text-[10px] text-clay/60 font-medium">ก๋วยเตี๋ยวเรือ บางแสน</span>
        </a>

        {/* CTAs */}
        <nav className="flex items-center gap-1.5" aria-label="quick actions">
          <a
            href={`tel:${PHONE}`}
            className="btn-ghost text-brand-600 font-semibold"
            aria-label="โทรหาร้าน"
          >
            <PhoneIcon /> <span className="hidden sm:inline">โทร</span>
          </a>
          <a
            href={MAP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost"
            aria-label="เปิดแผนที่"
          >
            <MapIcon /> <span className="hidden sm:inline">แผนที่</span>
          </a>
          <a
            href={DELIVERY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-sm px-4 py-2"
            aria-label="สั่งเดลิเวอรี่"
          >
            <DeliveryIcon />
            <span>สั่งเดลิเวอรี่</span>
          </a>
        </nav>
      </div>
    </header>
  )
}

function PhoneIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
    </svg>
  )
}

function MapIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
  )
}

function DeliveryIcon() {
  return (
    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
    </svg>
  )
}
