import { MAP_URL, ADDRESS } from '../app/constants'

export default function Location() {
  return (
    <section id="location" className="bg-cream py-14 px-4" aria-labelledby="location-heading">
      <div className="mx-auto max-w-3xl text-center">
        <h2 id="location-heading" className="section-title mb-2">แผนที่ &amp; การเดินทาง</h2>
        <p className="text-clay/60 mb-8 text-base">
          ตั้งอยู่บน ชบ. 1073 ถนนข้าวหลาม บางแสน
          <br />
          <span className="text-sm">{ADDRESS}</span>
        </p>

        {/* Map placeholder — replace with <iframe> embed if desired */}
        <div className="relative mx-auto mb-6 overflow-hidden rounded-2xl border border-brand-100 bg-gradient-to-br from-green-100 to-teal-100 shadow-sm"
          style={{ aspectRatio: '16/7' }}>
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-4">
            <span className="text-5xl" aria-hidden="true">🗺️</span>
            <p className="text-sm font-medium text-clay/70 max-w-xs text-center">
              ฝัง Google Maps ได้โดยใช้ &lt;iframe&gt; embed
              <br />หรือกดปุ่มด้านล่างเพื่อเปิดแผนที่
            </p>
          </div>
        </div>

        {/* How to get there */}
        <div className="mb-8 rounded-2xl bg-warm border border-brand-100 p-5 text-left">
          <h3 className="font-bold text-clay mb-3">วิธีการเดินทาง</h3>
          <ul className="space-y-2 text-sm text-clay/70">
            <li className="flex gap-2"><span aria-hidden="true">🚗</span> มาทางถนนข้าวหลาม มุ่งหน้าบางแสน จะเห็นป้ายร้านด้านซ้าย</li>
            <li className="flex gap-2"><span aria-hidden="true">🚌</span> นั่งรถสองแถวสาย ชลบุรี–บางแสน แล้วลงที่จุดใกล้เคียง</li>
            <li className="flex gap-2"><span aria-hidden="true">🅿️</span> มีที่จอดรถหน้าร้าน</li>
          </ul>
        </div>

        <a
          href={MAP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-primary text-lg px-10 py-4 inline-flex"
          aria-label="เปิดแผนที่ใน Google Maps"
        >
          📍 เปิด Google Maps
        </a>
      </div>
    </section>
  )
}
