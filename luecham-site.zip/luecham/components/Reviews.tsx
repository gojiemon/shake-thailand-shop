const reviews = [
  { quote: 'เมนูเยอะ เลือกได้ทั้งข้าวและเส้น ถูกใจคนกินง่ายๆ มาก' },
  { quote: 'ร้านโปร่ง นั่งสบาย มีทั้งในร้านและในสวน อากาศดีมาก' },
  { quote: 'รสเข้มข้น อิ่มคุ้ม ราคาเป็นมิตร มาบ่อยมากเลย' },
]

export default function Reviews() {
  return (
    <section id="reviews" className="bg-cream py-14 px-4" aria-labelledby="reviews-heading">
      <div className="mx-auto max-w-3xl">
        <h2 id="reviews-heading" className="section-title text-center mb-2">เสียงจากลูกค้า</h2>
        <p className="text-center text-clay/60 mb-10 text-base">จากผู้รีวิวที่มาใช้บริการจริง</p>

        <div className="flex flex-col gap-4">
          {reviews.map((r, i) => (
            <blockquote
              key={i}
              className="card p-5 flex items-start gap-4"
            >
              <span className="mt-1 flex-shrink-0 text-brand-400 text-3xl leading-none" aria-hidden="true">"</span>
              <div>
                <p className="text-base text-clay leading-relaxed font-medium">{r.quote}</p>
                <footer className="mt-2 text-xs text-clay/50">— จากผู้รีวิว</footer>
              </div>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  )
}
