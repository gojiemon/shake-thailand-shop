'use client'
import Image from 'next/image'
import { useState } from 'react'

const galleryImages = [
  { src: '/images/gallery-1.jpg', alt: 'ก๋วยเตี๋ยวเรือหมูน้ำซุปเข้มข้นสวยงาม' },
  { src: '/images/gallery-2.jpg', alt: 'หมี่กระเฉดกุ้งสดใหม่จากร้าน' },
  { src: '/images/gallery-3.jpg', alt: 'สุกี้แห้งทะเลรสเด็ด' },
  { src: '/images/gallery-4.jpg', alt: 'บรรยากาศร้านโปร่งสบาย มีโต๊ะมาก' },
  { src: '/images/gallery-5.jpg', alt: 'มุมนั่งในสวนบรรยากาศร่มรื่น' },
  { src: '/images/gallery-6.jpg', alt: 'ผัดไทยกุ้งสดเส้นสวย' },
]

// Placeholder gradient colors per image slot
const placeholderColors = [
  'from-amber-200 to-orange-300',
  'from-green-200 to-teal-300',
  'from-red-200 to-rose-300',
  'from-sky-200 to-blue-300',
  'from-lime-200 to-green-300',
  'from-yellow-200 to-amber-300',
]

function GalleryItem({ item, color }: { item: (typeof galleryImages)[0]; color: string }) {
  const [error, setError] = useState(false)

  return (
    <div className="relative aspect-square overflow-hidden rounded-xl bg-gradient-to-br border border-brand-100 shadow-sm hover:shadow-md transition-shadow duration-200 group">
      {!error ? (
        <Image
          src={item.src}
          alt={item.alt}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          onError={() => setError(true)}
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
        />
      ) : (
        <div className={`absolute inset-0 bg-gradient-to-br ${color} flex flex-col items-center justify-center gap-2 p-3`}>
          <span className="text-3xl" aria-hidden="true">📷</span>
          <p className="text-center text-xs text-clay/70 font-medium leading-tight">{item.alt}</p>
        </div>
      )}
    </div>
  )
}

export default function Gallery() {
  return (
    <section id="gallery" className="bg-warm py-14 px-4" aria-labelledby="gallery-heading">
      <div className="mx-auto max-w-5xl">
        <h2 id="gallery-heading" className="section-title text-center mb-2">แกลเลอรี</h2>
        <p className="text-center text-clay/60 mb-10 text-base">ชมบรรยากาศร้านและเมนูเด็ด</p>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-3">
          {galleryImages.map((img, i) => (
            <GalleryItem key={img.src} item={img} color={placeholderColors[i]} />
          ))}
        </div>

        <p className="mt-4 text-center text-xs text-clay/40">
          ใส่รูปภาพจริงได้ที่โฟลเดอร์ <code className="bg-brand-50 px-1 rounded">public/images/</code>
        </p>
      </div>
    </section>
  )
}
