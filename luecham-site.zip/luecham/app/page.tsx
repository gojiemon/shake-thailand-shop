// ─────────────────────────────────────────────────────────────────────────────
// 🔧 REPLACE THESE URLS BEFORE GOING LIVE
// ─────────────────────────────────────────────────────────────────────────────
export const MAP_URL = 'https://maps.google.com/?q=ลือชาม+ก๋วยเตี๋ยวเรือ+บางแสน+ชลบุรี'
export const DELIVERY_URL = 'https://www.foodpanda.co.th' // Replace with actual store page URL
// ─────────────────────────────────────────────────────────────────────────────

import TopBar from '@/components/TopBar'
import Hero from '@/components/Hero'
import Highlights from '@/components/Highlights'
import Menu from '@/components/Menu'
import Gallery from '@/components/Gallery'
import Reviews from '@/components/Reviews'
import Info from '@/components/Info'
import Location from '@/components/Location'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <>
      <TopBar />
      <main>
        <Hero />
        <Highlights />
        <Menu />
        <Gallery />
        <Reviews />
        <Info />
        <Location />
      </main>
      <Footer />
    </>
  )
}
