// ─── Replace these URLs before going live ──────────────────────────────────
export const MAP_URL = 'https://maps.google.com/?q=ลือชาม+ก๋วยเตี๋ยวเรือ+บางแสน+ชลบุรี'
export const DELIVERY_URL = 'https://www.foodpanda.co.th' // Replace with actual store URL

// ─── Restaurant Info ────────────────────────────────────────────────────────
export const PHONE = '0648719945'
export const PHONE_DISPLAY = '064-871-9945'
export const HOURS = '07:30–17:30'
export const ADDRESS = 'ชบ. 1073, 4 ห้วยกะปิ เมืองชลบุรี ชลบุรี'
