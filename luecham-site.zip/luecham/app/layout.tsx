import type { Metadata } from 'next'
import { Sarabun } from 'next/font/google'
import './globals.css'

const sarabun = Sarabun({
  subsets: ['thai', 'latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-sarabun',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'ลือชาม ก๋วยเตี๋ยวเรือ | บางแสน ชลบุรี',
  description:
    'ก๋วยเตี๋ยวเรือรสเข้มข้น เมนูหลากหลาย ทั้งข้าว เส้น ผัด สปาเก็ตตี้ เปิดเช้า 07:30–17:30 ถนนข้าวหลาม บางแสน ชลบุรี',
  keywords: 'ก๋วยเตี๋ยวเรือ, บางแสน, ชลบุรี, หมี่กระเฉด, สุกี้แห้ง, อาหาร',
  openGraph: {
    title: 'ลือชาม ก๋วยเตี๋ยวเรือ ถนนข้าวหลามบางแสน',
    description: 'เข้มข้นทุกชาม อิ่มคุ้มทุกวัน เปิดเช้า 07:30 ทุกวัน',
    type: 'website',
    locale: 'th_TH',
    siteName: 'ลือชาม ก๋วยเตี๋ยวเรือ',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="th" className={sarabun.variable}>
      <body className="font-display bg-cream text-clay antialiased">{children}</body>
    </html>
  )
}
